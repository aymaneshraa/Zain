// إعدادات Supabase العامة لمتجر ZAIN STORE. لا تضع service_role key هنا.
window.ZAIN_CONFIG = {
  SUPABASE_URL: "https://vjuprwjwjcunqyjsbaxo.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_IvoLi8cExxMy45l-HNH_-g_g_6drmeb"
};
