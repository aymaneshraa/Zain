// ضع بيانات Supabase العامة هنا. لا تضع service_role key في هذا الملف.
window.ZAIN_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY"
};
