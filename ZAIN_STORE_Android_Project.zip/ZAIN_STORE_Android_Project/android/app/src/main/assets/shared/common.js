window.zainClient = function () {
  const c = window.ZAIN_CONFIG || {};
  if (!c.SUPABASE_URL || c.SUPABASE_URL.includes("YOUR_") ||
      !c.SUPABASE_ANON_KEY || c.SUPABASE_ANON_KEY.includes("YOUR_")) {
    throw new Error("أكمل إعدادات Supabase داخل shared/config.js أولًا");
  }
  return window.supabase.createClient(c.SUPABASE_URL, c.SUPABASE_ANON_KEY);
};
window.money = n => new Intl.NumberFormat('ar-EG', {style:'currency',currency:'EGP'}).format(Number(n||0));
window.escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
