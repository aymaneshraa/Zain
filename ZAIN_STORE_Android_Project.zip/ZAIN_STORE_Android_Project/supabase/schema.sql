create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'كاميرات مراقبة',
  description text not null default '',
  image_url text not null default '',
  price numeric(12,2) not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  governorate text not null,
  address text not null,
  notes text not null default '',
  total numeric(12,2) not null default 0,
  status text not null default 'جديد'
    check (status in ('جديد','قيد التأكيد','تم التأكيد','قيد الشحن','تم التسليم','ملغي')),
  payment_method text not null default 'الدفع عند الاستلام',
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price numeric(12,2) not null,
  quantity integer not null check (quantity > 0),
  line_total numeric(12,2) not null
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "public read active products" on public.products;
create policy "public read active products" on public.products for select to anon, authenticated
using (active = true or public.is_admin());

drop policy if exists "admin manage products" on public.products;
create policy "admin manage products" on public.products for all to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin read orders" on public.orders;
create policy "admin read orders" on public.orders for select to authenticated
using (public.is_admin());

drop policy if exists "admin update orders" on public.orders;
create policy "admin update orders" on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin read order items" on public.order_items;
create policy "admin read order items" on public.order_items for select to authenticated
using (public.is_admin());

-- الطلب يُنشأ من خلال دالة تتحقق من الأسعار والمخزون داخل قاعدة البيانات.
create or replace function public.place_order(
  p_customer_name text,
  p_phone text,
  p_governorate text,
  p_address text,
  p_notes text,
  p_items jsonb
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid;
  v_total numeric(12,2) := 0;
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty integer;
begin
  if length(trim(coalesce(p_customer_name,''))) < 2
     or length(trim(coalesce(p_phone,''))) < 8
     or length(trim(coalesce(p_address,''))) < 5
     or jsonb_typeof(p_items) <> 'array'
     or jsonb_array_length(p_items) = 0 then
    raise exception 'بيانات الطلب غير مكتملة';
  end if;

  insert into public.orders(customer_name, phone, governorate, address, notes, total)
  values(trim(p_customer_name), trim(p_phone), trim(p_governorate),
         trim(p_address), coalesce(p_notes,''), 0)
  returning id into v_order_id;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_qty := greatest(1, least(99, (v_item->>'quantity')::integer));
    select * into v_product from public.products
      where id = (v_item->>'product_id')::uuid and active = true
      for update;
    if not found then raise exception 'أحد المنتجات لم يعد متاحًا'; end if;
    if v_product.stock < v_qty then raise exception 'الكمية غير متوفرة: %', v_product.name; end if;

    update public.products set stock = stock - v_qty where id = v_product.id;
    insert into public.order_items(order_id, product_id, product_name, unit_price, quantity, line_total)
    values(v_order_id, v_product.id, v_product.name, v_product.price, v_qty, v_product.price * v_qty);
    v_total := v_total + v_product.price * v_qty;
  end loop;

  update public.orders set total = v_total where id = v_order_id;
  return v_order_id;
end;
$$;

grant execute on function public.place_order(text,text,text,text,text,jsonb) to anon, authenticated;

-- أنشئ مستخدمًا من Authentication ثم امنحه صلاحية الإدارة:
-- update public.profiles set role='admin'
-- where id=(select id from auth.users where email='YOUR_EMAIL');

-- إنشاء profile تلقائيًا لكل حساب جديد.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, role) values(new.id, 'customer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
